# Others

Date: 2021/03/20
Language: Java

## 오늘 한 일

---

1. Java의 역사 탐방!
    - MS Internet Explorer의 흥망성쇠
    - 웹 브라우저 전국 시대에 구세군이 된 JQuery의 등장 배경
    - Chrome의 등장과 ECMAScript의 변천사

---

## 내일 할 일

---

1. Cub3D 구현으로 다시 돌아가기!

---