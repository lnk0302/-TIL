# Cub3d

Date: 2021/04/07
Language: C

## 오늘 한 일

---

1. exit && 에러코드 정리
    - cub3d 프로그램의 정상/비정상 종료 케이스 분류하여 `exit()`
2. 코드정리
    - 테스트를 위한 라인정리
3. bitmap 작성을 위한 스터디

---

## 내일 할 일

---

1. bitmap 정리 계속
2. data parse 예외처리 보강

---